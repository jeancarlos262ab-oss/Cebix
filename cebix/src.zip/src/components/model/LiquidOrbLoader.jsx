/**
 * LiquidOrbLoader — "liquid orb" en CSS puro, siempre presente.
 *
 * Pensado como reemplazo ligero del shader WebGPU original: en vez de
 * renderizar fluido por fragment shader, usa 3 blobs radiales borrosos
 * (filter: blur) animados con transform/rotate dentro de un círculo con
 * overflow:hidden. Solo composita transform + opacity, así que corre en el
 * compositor de la GPU sin tocar layout ni pintar por frame — barato incluso
 * en equipos modestos, y respeta prefers-reduced-motion.
 *
 * `running` controla el estado: en reposo deriva despacio como decoración;
 * al pasar a `true` hace zoom (scale) y los blobs aceleran, para marcar que
 * el modelo está trabajando de verdad.
 */
export default function LiquidOrbLoader({ size = 88, running = false, label }) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div
        className={`liquid-orb relative shrink-0 overflow-hidden rounded-full ${
          running ? "liquid-orb--active" : ""
        }`}
        style={{ width: size, height: size, "--orb-speed": running ? 1.8 : 1 }}
        role="status"
        aria-label={label || (running ? "Ejecutando modelo" : "En espera")}
      >
        <span className="liquid-orb__blob liquid-orb__blob--a" />
        <span className="liquid-orb__blob liquid-orb__blob--b" />
        <span className="liquid-orb__blob liquid-orb__blob--c" />
        <span className="liquid-orb__sheen" />
        <span className="liquid-orb__ring" />
      </div>
      {label && (
        <p className="text-center text-xs font-medium text-gray-500 dark:text-gray-400">
          {label}
        </p>
      )}

      <style>{`
        .liquid-orb {
          background: radial-gradient(circle at 35% 30%, #0d1522, #030409 72%);
          box-shadow:
            0 0 0 1px rgba(255, 255, 255, 0.06) inset,
            0 8px 30px -12px rgba(0, 0, 0, 0.55);
          transform: scale(1);
          transition: transform 0.7s cubic-bezier(0.22, 1, 0.36, 1),
            box-shadow 0.7s ease;
        }

        .liquid-orb--active {
          transform: scale(1.35);
          box-shadow:
            0 0 0 1px rgba(255, 255, 255, 0.12) inset,
            0 0 40px -6px var(--accent-500, #c08a2e),
            0 12px 40px -14px rgba(0, 0, 0, 0.65);
        }

        .liquid-orb__blob {
          position: absolute;
          inset: -20%;
          border-radius: 999px;
          filter: blur(14px);
          mix-blend-mode: screen;
          opacity: 0.85;
          will-change: transform;
        }

        .liquid-orb__blob--a {
          background: radial-gradient(circle, var(--accent-500, #c08a2e) 0%, transparent 62%);
          animation: liquidOrbDrift calc(5.2s / var(--orb-speed, 1)) ease-in-out infinite;
        }

        .liquid-orb__blob--b {
          background: radial-gradient(circle, #4c9a63 0%, transparent 60%);
          animation: liquidOrbDrift calc(6.4s / var(--orb-speed, 1)) ease-in-out infinite reverse;
          animation-delay: -1.4s;
        }

        .liquid-orb__blob--c {
          background: radial-gradient(circle, #9bc4ff 0%, transparent 58%);
          opacity: 0.55;
          animation: liquidOrbDrift calc(4.4s / var(--orb-speed, 1)) ease-in-out infinite;
          animation-delay: -2.6s;
        }

        .liquid-orb__sheen {
          position: absolute;
          inset: 0;
          border-radius: inherit;
          background: radial-gradient(circle at 32% 26%, rgba(255, 255, 255, 0.55), transparent 45%);
          mix-blend-mode: overlay;
          animation: liquidOrbBreathe calc(3.2s / var(--orb-speed, 1)) ease-in-out infinite;
        }

        .liquid-orb__ring {
          position: absolute;
          inset: 0;
          border-radius: inherit;
          box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.12) inset;
          pointer-events: none;
        }

        @keyframes liquidOrbDrift {
          0%   { transform: translate(-6%, -4%) scale(1) rotate(0deg); }
          33%  { transform: translate(8%, 6%) scale(1.15) rotate(60deg); }
          66%  { transform: translate(-4%, 8%) scale(0.92) rotate(140deg); }
          100% { transform: translate(-6%, -4%) scale(1) rotate(360deg); }
        }

        @keyframes liquidOrbBreathe {
          0%, 100% { opacity: 0.35; }
          50%      { opacity: 0.7; }
        }

        @media (prefers-reduced-motion: reduce) {
          .liquid-orb__blob,
          .liquid-orb__sheen {
            animation: none;
          }
        }
      `}</style>
    </div>
  );
}
