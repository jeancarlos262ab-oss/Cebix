import { lazy, memo, Suspense, useEffect, useMemo, useRef, useState } from "react";
import L from "leaflet";
import { MapContainer, TileLayer, Pane, Polygon, Polyline, Marker, GeoJSON, useMap, useMapEvents } from "react-leaflet";
import { Check, Eraser, Globe, MousePointer2, Pencil, Undo2 } from "lucide-react";
import MapControls from "./MapControls";
import { GHOST, PANEL, PRIMARY, STATUS } from "./mapUi";
import { preloadWorldTiles } from "./tilePreload";
import { usePageActive } from "../../context/PageActiveContext";
import { estadoBounds, toGeoJSONPolygon } from "../../utils/polygon";
import { reportGLFailure, resolveMapEngine } from "../../utils/mapDevice";
import { loadGlobeMapGL } from "../../utils/mapLoaders";
import { parcelGridLines } from "../../utils/parcelGrid";
import { ESTADOS } from "./config";
import {
  GRID_WEIGHT,
  IMAGERY_CREDIT,
  IMAGERY_URL,
  OUTLINE_WEIGHT,
  EXPORT_COLOR,
  EXPORT_DASH,
  EXPORT_LABEL,
  EXPORT_WEIGHT,
  OVER_LIMIT_COLOR,
  OVER_LIMIT_FILL_OPACITY,
  STUDY,
  STUDY_BOUNDS as START_BOUNDS,
  drawStatus,
  statusDot,
  traceBlend,
  traceColor,
  vertexLook,
} from "./parcelStyle";
import estadosBoundaries from "../../data/estadosBoundaries.json";
import { boundaryLeafletStyle } from "../map/boundaryStyle";
import { useTheme } from "../../context/ThemeContext";
import { getAccentHex } from "../../utils/accentColors";
import "leaflet/dist/leaflet.css";

// Globo 3D, cargado solo cuando se necesita. Si el equipo acepta WebGL se usa MapLibre GL con
// proyección de globo; si no (PCs sin potencia / sin aceleración), el globo ligero de Canvas 2D.
const GlobeMapCanvas = lazy(() => import("./GlobeMap"));
const GlobeMapGL = lazy(loadGlobeMapGL);

const SATELLITE = { url: IMAGERY_URL };
// Un solo mundo: sin copias repetidas en tiras y con el zoom mínimo limitado a lo que cabe en el mapa.
const WORLD = [
  [-85.05, -180],
  [85.05, 180],
];
const WORLD_BOUNDS = L.latLngBounds(WORLD);
function limitMinZoom(map) {
  map.setMaxBounds(WORLD_BOUNDS);
  map.options.maxBoundsViscosity = 1;
  const { x, y } = map.getSize();
  if (!x || !y) return;
  const z = map.getBoundsZoom(WORLD, true); // el mundo llena el recuadro, sin huecos
  map.setMinZoom(z);
  if (map.getZoom() < z) map.setZoom(z, { animate: false });
}

// Encuadre inicial: Hidalgo, Tlaxcala y Puebla (START_BOUNDS = STUDY_BOUNDS de parcelStyle.js).

// Vértices: el diseño sale de parcelStyle.vertexLook, el mismo que usa el mapa de MapLibre.
const vertexIcon = (closeTarget, color) => {
  const { size, css } = vertexLook(closeTarget, color);
  return L.divIcon({
    className: "",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    html: `<span style="display:block;width:100%;height:100%;box-sizing:border-box;border-radius:50%;${css}"></span>`,
  });
};

/** Clics del mapa: solo agregan vértices mientras se dibuja (y se evita el zoom por doble clic). */
function DrawEvents({ drawing, onAdd }) {
  const map = useMap();
  useEffect(() => {
    if (drawing) map.doubleClickZoom.disable();
    else map.doubleClickZoom.enable();
    map.getContainer().style.cursor = drawing ? "crosshair" : "";
    return () => {
      map.doubleClickZoom.enable();
      map.getContainer().style.cursor = "";
    };
  }, [drawing, map]);
  useMapEvents({ click: (e) => drawing && onAdd([e.latlng.lat, e.latlng.lng]) });
  return null;
}

/** Re-mide el mapa al volver a la pantalla (keep-alive) y encuadra el polígono cuando `fitKey` cambia. */
function MapSync({ fitKey, points }) {
  const map = useMap();
  const active = usePageActive();
  useEffect(() => {
    if (active) {
      const id = setTimeout(() => map.invalidateSize(), 50);
      return () => clearTimeout(id);
    }
  }, [active, map]);
  // Cubre también la pestaña oculta (display:none) y el cambio de tamaño de la ventana.
  useEffect(() => {
    const ro = new ResizeObserver(() => {
      map.invalidateSize();
      limitMinZoom(map); // también al pasar a pantalla completa o cambiar el tamaño de la ventana
    });
    ro.observe(map.getContainer());
    return () => ro.disconnect();
  }, [map]);
  // Recorte duro: la vista nunca sale del mundo, ni arrastrando ni con la inercia del movimiento.
  useEffect(() => {
    const clamp = () => {
      if (!WORLD_BOUNDS.contains(map.getBounds())) map.panInsideBounds(WORLD_BOUNDS, { animate: false });
    };
    map.on("drag", clamp);
    map.on("moveend", clamp);
    return () => {
      map.off("drag", clamp);
      map.off("moveend", clamp);
    };
  }, [map]);
  useEffect(() => {
    if (fitKey && points.length >= 3) map.fitBounds(L.latLngBounds(points), { padding: [70, 70], maxZoom: 17 });
  }, [fitKey]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

/** Amplía unos límites [[s,w],[n,e]] por un factor alrededor de su centro. */
function widen([[s, w], [n, e]], f) {
  const cy = (s + n) / 2;
  const cx = (w + e) / 2;
  const hy = ((n - s) / 2) * f;
  const hx = ((e - w) / 2) * f;
  return [
    [cy - hy, cx - hx],
    [cy + hy, cx + hx],
  ];
}

/** Cambia el modo de mezcla de un panel de Leaflet ya creado (react-leaflet solo lo aplica al crearlo). */
function PaneBlend({ name, blend }) {
  const map = useMap();
  useEffect(() => {
    const el = map.getPane(name);
    if (el) el.style.mixBlendMode = blend;
  }, [map, name, blend]);
  return null;
}

/**
 * Mapa satelital plano con dibujo de polígono (Leaflet, sin plugins).
 * Controlado por el padre: `points` ([lat,lng][]), `closed` y `drawing`.
 * `target` ([[s,w],[n,e]]): si viene del globo, arranca amplio y vuela hasta esa zona.
 */
function FlatGeometryMap({
  points,
  closed,
  drawing,
  locked,
  overLimit = false,
  fitKey,
  entry,
  active,
  onChange,
  onStartDrawing,
  onFinish,
  onClear,
  onUndo,
  onOpenGlobe,
  isFullscreen,
  onToggleFullscreen,
}) {
  const [map, setMap] = useState(null);
  const [startBounds] = useState(() => {
    if (entry.target) return widen(entry.target, 5);
    if (points.length >= 3) return L.latLngBounds(points).pad(0.4);
    return START_BOUNDS;
  });
  // Cada vez que se entra desde el globo: encuadra amplio y vuela a la zona elegida.
  const lastEntry = useRef(entry.key);
  useEffect(() => {
    if (!map || !active || !entry.target || lastEntry.current === entry.key) return;
    lastEntry.current = entry.key;
    map.invalidateSize(false);
    map.fitBounds(widen(entry.target, 5), { animate: false });
    const id = setTimeout(() => map.flyToBounds(entry.target, { duration: 1.3, padding: [30, 30], maxZoom: 17 }), 150);
    return () => clearTimeout(id);
  }, [map, active, entry]);
  // La primera entrada (mapa recién creado) también vuela.
  useEffect(() => {
    if (!map || !entry.target) return;
    const id = setTimeout(() => map.flyToBounds(entry.target, { duration: 1.3, padding: [30, 30], maxZoom: 17 }), 150);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map]);
  const ready = points.length >= 3;
  // Malla en perspectiva que se adapta a la forma de la parcela ya cerrada.
  const gridLines = useMemo(() => (closed && ready ? parcelGridLines(points) : []), [closed, ready, points]);
  // Anillo que se descarga, como [lat,lng][] (mismo redondeo a 6 decimales que el GeoJSON).
  const exportRing = useMemo(
    () => (closed && ready ? toGeoJSONPolygon(points).coordinates[0].map(([lng, lat]) => [lat, lng]) : []),
    [closed, ready, points],
  );
  const { accent, resolvedTheme } = useTheme();
  const accentHex = getAccentHex(accent, resolvedTheme);
  const stateStyle = useMemo(() => boundaryLeafletStyle(accentHex), [accentHex]);

  // Pasada la superficie máxima, el contorno y la malla se pintan en rojo (sin el modo "difference", que
  // alteraría el color). El modo de mezcla del panel se cambia aquí, en el propio elemento del panel.
  const color = traceColor(overLimit);

  const status =
    drawStatus({ locked, drawing, ready, closed, count: points.length }) ??
    "Pulsa 'Dibujar parcela' y marca el contorno sobre la imagen";

  return (
    <div className="relative h-full min-h-[300px] w-full overflow-hidden">
      <MapContainer
        ref={setMap}
        bounds={startBounds}
        zoomControl={false}
        attributionControl={false}
        fadeAnimation={false}
        maxBounds={WORLD}
        maxBoundsViscosity={1}
        maxZoom={19}
        className="absolute inset-0 bg-gray-100 dark:bg-gray-900"
      >
        {/* Capa base de vista general: siempre hay imagen debajo mientras llegan las teselas nítidas. */}
        <TileLayer url={SATELLITE.url} noWrap minNativeZoom={2} maxNativeZoom={5} maxZoom={19} zIndex={1} keepBuffer={2} />
        <TileLayer
          {...SATELLITE}
          noWrap
          maxNativeZoom={17}
          maxZoom={19}
          zIndex={2}
          keepBuffer={5}
          updateWhenIdle={false}
          updateWhenZooming={false}
        />
        <GeoJSON key={accentHex} data={estadosBoundaries} style={() => stateStyle} interactive={false} />

        {/* Dibujo de la parcela con contraste invertido: trazos blancos en modo "difference" invierten el color
            de la imagen que tienen debajo, así se leen sobre cualquier tono. El modo de mezcla va en el panel
            (no en cada trazo) porque los paneles de Leaflet son contextos de apilamiento aislados. */}
        <Pane name="parcel" style={{ zIndex: 450, mixBlendMode: traceBlend(false) }}>
          <PaneBlend name="parcel" blend={traceBlend(overLimit)} />
          {points.length >= 2 && !closed && (
            <Polyline positions={points} pathOptions={{ color, weight: OUTLINE_WEIGHT }} interactive={false} />
          )}
          {closed && ready && (
            <>
              <Polygon
                positions={points}
                pathOptions={{
                  color,
                  weight: OUTLINE_WEIGHT,
                  lineJoin: "miter",
                  fill: overLimit,
                  fillColor: OVER_LIMIT_COLOR,
                  fillOpacity: overLimit ? OVER_LIMIT_FILL_OPACITY : 0,
                }}
                interactive={false}
              />
              {gridLines.length > 0 && (
                <Polyline positions={gridLines} pathOptions={{ color, weight: GRID_WEIGHT }} interactive={false} />
              )}
            </>
          )}

          {points.map((p, i) => {
            const closeTarget = drawing && ready && i === 0;
            return (
              <Marker
                key={`${i}-${closeTarget}`}
                position={p}
                draggable={!locked && !drawing}
                icon={vertexIcon(closeTarget, color)}
                eventHandlers={{
                  click: () => closeTarget && onFinish(),
                  dragend: (e) => {
                    const { lat, lng } = e.target.getLatLng();
                    onChange(points.map((q, k) => (k === i ? [lat, lng] : q)));
                  },
                }}
              />
            );
          })}
        </Pane>

        {/* Contorno que se descarga: el anillo exacto de toGeoJSONPolygon, en un panel aparte con mezcla normal
            (el panel "parcel" usa "difference" y alteraría el color). */}
        <Pane name="export" style={{ zIndex: 460 }}>
          {closed && ready && (
            <Polyline
              positions={exportRing}
              pathOptions={{ color: EXPORT_COLOR, weight: EXPORT_WEIGHT, dashArray: EXPORT_DASH.join(" "), lineCap: "butt" }}
              interactive={false}
            />
          )}
        </Pane>

        <DrawEvents drawing={drawing && !locked} onAdd={(p) => onChange([...points, p])} />
        <MapSync fitKey={fitKey} points={points} />
      </MapContainer>

      {/* Herramientas de dibujo (a la izquierda) y cambio de vista (separado, al final) */}
      <div className="pointer-events-none absolute left-3 top-3 z-1000">
        <div className={`pointer-events-auto flex items-center gap-0.5 p-1 ${PANEL}`}>
          {drawing ? (
            <button type="button" onClick={onFinish} disabled={!ready || locked} className={PRIMARY}>
              <Check size={14} /> Terminar
            </button>
          ) : (
            <button type="button" onClick={onStartDrawing} disabled={locked} className={PRIMARY}>
              {closed ? <MousePointer2 size={14} /> : <Pencil size={14} />}
              {closed ? "Redibujar" : "Dibujar parcela"}
            </button>
          )}
          <button type="button" aria-label="Deshacer último vértice" title="Deshacer último vértice" onClick={onUndo} disabled={!drawing || !points.length || locked} className={GHOST}>
            <Undo2 size={14} /> <span className="hidden sm:inline">Deshacer</span>
          </button>
          <button type="button" aria-label="Borrar parcela" title="Borrar parcela" onClick={onClear} disabled={!points.length || locked} className={GHOST}>
            <Eraser size={14} /> <span className="hidden sm:inline">Borrar</span>
          </button>
          <span className="mx-1 h-5 w-px bg-white/15" aria-hidden="true" />
          <button
            type="button"
            aria-label="Ver el globo"
            title="Volver al globo"
            onClick={() => {
              const c = map?.getCenter();
              onOpenGlobe(c ? { lat: c.lat, lon: c.lng } : { lat: STUDY.lat, lon: STUDY.lon });
            }}
            disabled={locked}
            className={GHOST}
          >
            <Globe size={14} strokeWidth={1.75} /> <span className="hidden sm:inline">Globo</span>
          </button>
        </div>
      </div>

      {/* Zoom y saltos a cada estado */}
      <div className="pointer-events-none absolute right-3 top-3 z-1000 flex flex-col items-end gap-2">
        <div className={`pointer-events-auto flex flex-col overflow-hidden ${PANEL}`}>
          <span className="px-3 pb-1 pt-2 text-[10px] font-medium uppercase tracking-wider text-gray-500">Ir a</span>
          {ESTADOS.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => map?.flyToBounds(estadoBounds(name), { duration: 0.8 })}
              className="px-3 py-1.5 text-left text-[11px] font-medium text-gray-300 hover:bg-white/10"
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      <MapControls
        onZoomIn={() => map?.zoomIn()}
        onZoomOut={() => map?.zoomOut()}
        onReset={() => map?.flyToBounds(START_BOUNDS, { duration: 0.8 })}
        isFullscreen={isFullscreen}
        onToggleFullscreen={onToggleFullscreen}
      />

      <div className="pointer-events-none absolute bottom-3 left-3 right-16 z-1000 flex flex-col items-start gap-1.5">
        <p className={STATUS} role="status">
          <span
            aria-hidden="true"
            className={`mr-2 inline-block size-1.5 align-middle ${statusDot({ locked, drawing })}`}
          />
          {status}
        </p>
        {closed && ready && (
          <p className="flex items-center gap-2 bg-black/60 px-1.5 py-0.5 text-[10px] text-gray-200">
            <span aria-hidden="true" className="inline-block h-0 w-5 border-t-2 border-dashed" style={{ borderColor: EXPORT_COLOR }} />
            {EXPORT_LABEL}
          </p>
        )}
        <p className="bg-black/60 px-1.5 py-0.5 text-[10px] text-gray-300">{IMAGERY_CREDIT}</p>
      </div>
    </div>
  );
}

/**
 * Pantalla de parcela satelital: arranca en un globo 3D (MapLibre GL con proyección de globo; en equipos sin WebGL, un globo ligero de Canvas 2D)
 * y entra al mapa plano para dibujar. Si ya hay una parcela o se importa un GeoJSON,
 * va directo al mapa plano.
 */
function GeometryMap(props) {
  const { points, fitKey, onStartDrawing } = props;
  const [view, setView] = useState(points.length ? "flat" : "globe");
  // Cada vista se crea UNA sola vez (la primera que se necesita) y se reutiliza: no se desmonta al cambiar.
  const [flatCreated, setFlatCreated] = useState(points.length > 0);
  const [globeCreated, setGlobeCreated] = useState(points.length === 0);
  const [flatEntry, setFlatEntry] = useState({ key: 0, target: null });
  const [globeEntry, setGlobeEntry] = useState({ key: 0, lat: 8, lon: -98.1 });
  const [lastFit, setLastFit] = useState(fitKey);
  // MapLibre GL si el equipo acepta WebGL; si falla al arrancar, se cae al globo de Canvas 2D.
  const [glFailed, setGlFailed] = useState(false);
  const useGL = !glFailed && resolveMapEngine() === "gl";
  const GlobeMap = GlobeMapCanvas;
  // Con MapLibre GL no hace falta: pide sus propias teselas y la precarga de 341 imágenes competiría con
  // la carga inicial del globo por las mismas conexiones.
  useEffect(() => {
    if (!useGL) preloadWorldTiles();
  }, [useGL]);
  const boxRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  useEffect(() => {
    const onChange = () => setIsFullscreen(document.fullscreenElement === boxRef.current);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);
  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    else boxRef.current?.requestFullscreen?.().catch(() => {});
  };

  const goFlat = (target) => {
    setFlatEntry((e) => ({ key: e.key + 1, target }));
    setFlatCreated(true);
    setView("flat");
  };
  const goGlobe = (c) => {
    setGlobeEntry((e) => ({ key: e.key + 1, ...c, zoom: 5.4 }));
    setGlobeCreated(true);
    setView("globe");
  };

  // Importar un GeoJSON salta directo al mapa plano (se ajusta durante el render, sin efecto).
  if (fitKey !== lastFit) {
    setLastFit(fitKey);
    if (fitKey) {
      setFlatCreated(true);
      setView("flat");
    }
  }

  // Si se empieza a dibujar desde el panel (no desde el globo), se pasa al mapa plano sobre la zona de estudio.
  if (!useGL && props.drawing && view === "globe") goFlat(START_BOUNDS);

  const pane = (on) =>
    `absolute inset-0 transition-[opacity,visibility] duration-300 ${on ? "visible opacity-100" : "invisible opacity-0"}`;

  // Con MapLibre GL todo vive en un solo mapa: globo, zoom y dibujo de la parcela.
  if (useGL) {
    return (
      <div ref={boxRef} className="relative h-full min-h-[300px] w-full [&:fullscreen]:bg-black">
        <Suspense fallback={<div className="h-full w-full bg-black" />}>
          <GlobeMapGL
            {...props}
            onFail={() => {
              reportGLFailure();
              setGlFailed(true);
            }}
            isFullscreen={isFullscreen}
            onToggleFullscreen={toggleFullscreen}
          />
        </Suspense>
      </div>
    );
  }

  // El contenedor es el que entra en pantalla completa, así sigue activa al cambiar de globo a mapa plano.
  return (
    <div ref={boxRef} className="relative h-full min-h-[300px] w-full [&:fullscreen]:bg-black">
      {globeCreated && (
        <div className={pane(view === "globe")}>
          <Suspense fallback={<div className="h-full w-full bg-black" />}>
            <GlobeMap
              entry={globeEntry}
              active={view === "globe"}
              onEnter={(bounds, draw, isStudyZone) => {
                // Si ya hay algo dibujado (parcela o trazo en curso) se conserva: nunca se borra al volver del
                // globo. "Ir a la zona de estudio" y "Dibujar parcela" regresan a ese dibujo en vez de a la región.
                const hasDrawing = points.length > 0;
                let target = bounds;
                if (hasDrawing && isStudyZone && points.length >= 2) {
                  const b = L.latLngBounds(points).pad(0.3);
                  target = [
                    [b.getSouth(), b.getWest()],
                    [b.getNorth(), b.getEast()],
                  ]; // arreglo [[s,w],[n,e]], el formato que esperan widen() y flyToBounds()
                }
                goFlat(target);
                if (draw && !hasDrawing) onStartDrawing();
              }}
              isFullscreen={isFullscreen}
              onToggleFullscreen={toggleFullscreen}
            />
          </Suspense>
        </div>
      )}
      {flatCreated && (
        <div className={pane(view === "flat")}>
          <FlatGeometryMap
            {...props}
            entry={flatEntry}
            active={view === "flat"}
            onOpenGlobe={goGlobe}
            isFullscreen={isFullscreen}
            onToggleFullscreen={toggleFullscreen}
          />
        </div>
      )}
    </div>
  );
}

export default memo(GeometryMap);
