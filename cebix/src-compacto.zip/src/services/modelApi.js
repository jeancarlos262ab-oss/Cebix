/**
 * Cliente de la API de inferencia (carpeta /backend). Es la ÚNICA fuente de datos del
 * modelo en el dashboard: predicciones, métricas, importancia SHAP y archivo de ejemplo.
 * No hay datos del modelo escritos en el código del frontend.
 */
import { getPredictionMode } from "./predictionMode";
import { MSG_CONNECTION, MSG_GENERIC, MSG_SERVICE, SHOW_REAL_ERRORS, isTechnical, realError } from "../utils/userMessages";

export const API_URL = (import.meta.env.VITE_MODEL_API_URL || "http://localhost:8000").replace(/\/$/, "");
export const EXAMPLE_CSV_URL = `${API_URL}/example-csv`;
// Descarga de ejemplo: solo los dos CSV que acepta el modelo (Básico y PRO/Planet), en un zip que vive en
// public/ejemplos/ (se sirve desde el propio sitio, sin pasar por el backend).
export const EXAMPLE_TODOS_URL = `${import.meta.env.BASE_URL}ejemplos/Archivos_de_ejemplo.zip`;

/** Error de la API con los datos reales de la respuesta (código HTTP, URL y cuerpo crudo). */
export class ApiError extends Error {
  constructor(message, { status, url, raw } = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.url = url;
    this.raw = raw;
  }
}

// FastAPI manda `detail` como texto, como lista de errores de validación (422) o como objeto.
function detailToText(detail) {
  if (detail == null) return "";
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail))
    return detail
      .map((d) => {
        if (typeof d === "string") return d;
        const loc = Array.isArray(d?.loc) ? d.loc.filter((x) => x !== "body").join(".") : "";
        const msg = d?.msg ?? JSON.stringify(d);
        return loc ? `${loc}: ${msg}` : msg;
      })
      .join("\n");
  if (typeof detail === "object") return detail.message ?? detail.error ?? JSON.stringify(detail);
  return String(detail);
}

/** Convierte una respuesta no exitosa en un ApiError con el mensaje real del servidor. */
export async function errorFromResponse(res) {
  const raw = (await res.text().catch(() => "")).trim();
  let detail = "";
  try {
    const json = JSON.parse(raw);
    detail = detailToText(json?.detail ?? json?.message ?? json?.error ?? json);
  } catch {
    // Cuerpo que no es JSON (p. ej. la página de error de un proxy): no se usa como mensaje.
    detail = raw && !raw.startsWith("<") ? raw.slice(0, 500) : "";
  }
  // El detalle crudo (código HTTP, URL, cuerpo) queda en el error para la consola; el mensaje es para la persona.
  let message;
  if (res.status >= 500) message = MSG_SERVICE;
  else if (res.status === 413) message = "El archivo es demasiado grande.";
  else if (detail && !isTechnical(detail)) message = detail;
  else message = MSG_GENERIC;
  console.error(`[api] ${res.status} ${res.url}`, raw.slice(0, 500));
  if (SHOW_REAL_ERRORS) message = `HTTP ${res.status} ${res.url} → ${detail || raw.slice(0, 400) || "(sin cuerpo)"}`;
  return new ApiError(message, { status: res.status, url: res.url, raw: raw.slice(0, 4000) });
}

/** POST /predict-csv — ejecuta el modelo real sobre un File. `modo`: "lluvia" (por defecto) o "10var". Devuelve { n_parcelas, modelo, modo, predicciones }. */
export async function predictCsv(file, modo = getPredictionMode()) {
  const formData = new FormData();
  formData.append("file", file); // el backend detecta solo si es el CSV Básico, el PRO (Planet) o uno de features
  const res = await fetch(`${API_URL}/predict-csv?modo=${encodeURIComponent(modo)}`, { method: "POST", body: formData });
  if (!res.ok) throw await errorFromResponse(res);
  return res.json();
}

/** GET /model-info — métricas de validación, SHAP global, comparación de algoritmos, textos. */
export async function fetchModelInfo() {
  const res = await fetch(`${API_URL}/model-info`);
  if (!res.ok) throw await errorFromResponse(res);
  return res.json();
}

/** GET /example-csv — el archivo de ejemplo del backend, como File listo para enviar. */
export async function fetchExampleFile() {
  const res = await fetch(EXAMPLE_CSV_URL);
  if (!res.ok) throw new Error("No se pudo cargar el archivo de ejemplo. Inténtalo de nuevo.");
  const blob = await res.blob();
  return new File([blob], "datos_ejemplo.csv", { type: "text/csv" });
}

export function friendlyError(err) {
  if (SHOW_REAL_ERRORS) {
    console.error("[api] error real", err);
    const hint = err instanceof TypeError ? ` (sin respuesta del servidor ${API_URL}: apagado, caído, URL equivocada o bloqueo CORS; mira la pestaña Red/Console del navegador)` : "";
    return realError(err) + hint;
  }
  // Los navegadores usan un TypeError genérico cuando la petición ni siquiera llega a respuesta.
  if (err instanceof TypeError) {
    console.error("[api] sin respuesta del servidor", API_URL, err);
    return `${MSG_CONNECTION} (Servidor: ${API_URL}. Si es tu equipo, confirma que el backend esté encendido; si es Render, que haya terminado de desplegar.)`;
  }
  return err.message || MSG_GENERIC;
}
