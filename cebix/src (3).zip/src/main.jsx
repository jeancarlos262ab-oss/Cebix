import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import "./index.css";
import App from "./App.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { ThemeProvider } from "./context/ThemeContext.jsx";
import { ParcelsProvider } from "./context/ParcelsContext.jsx";
import { UsersProvider } from "./context/UsersContext.jsx";
import AppToaster from "./components/ui/AppToaster.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ThemeProvider>
      <AuthProvider>
        <ParcelsProvider>
          <UsersProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
            <AppToaster />
          </UsersProvider>
        </ParcelsProvider>
      </AuthProvider>
    </ThemeProvider>
  </StrictMode>
);
